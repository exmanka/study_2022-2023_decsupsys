from django.shortcuts import render
from django.http import HttpResponse, Http404
from scripts.main import huevo, get_films
import json


def index(request):
    return render(request, "page/index.html")


def get_list(request):
    if request.method == 'POST':
        print()
        rated_films = json.loads(request.body)
        print(rated_films, "RATED")
        rated_films = {key: float(rated_films[key]) for key in rated_films}
        films = huevo(rated_films)
        print(films, "FILMS")
        return HttpResponse(json.dumps(films))

    return HttpResponse(json.dumps(get_films()))
